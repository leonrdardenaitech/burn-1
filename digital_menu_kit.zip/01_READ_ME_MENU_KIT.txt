﻿========================================================================
BURN-1 SYSTEMS // DIGITAL MENU KIT DEPLOYMENT GUIDE
========================================================================
STEP 1: Open index.html in any text editor and swap out dish names and prices.
STEP 2: Drag the folder onto Netlify, GitHub Pages, or Firebase Hosting.
STEP 3: Point your QR code to your URL and print once!

﻿========================================================================
BURN-1 SYSTEMS // ZERO-PARTY DATA COLLECTION KIOSK DEPLOYMENT GUIDE
========================================================================

STEP 1: GENERATE YOUR WEBHOOK URL
---------------------------------
1. Log in to your Zapier, Make.com, or n8n account.
2. Create a new scenario/zap with a 'Custom Webhook' trigger.
3. Copy your unique Catch Webhook URL.

STEP 2: PASTE YOUR WEBHOOK LINK
-------------------------------
1. Open 'js/webhook-engine.js' in any text editor.
2. Locate Line 8 and replace the placeholder text with your webhook URL inside the quotes.

STEP 3: CUSTOMIZE BRAND COLORS (OPTIONAL)
-----------------------------------------
1. Open 'css/style.css' and edit the hex colors at the top.

STEP 4: LAUNCH ON TABLET
------------------------
1. Open 'index.html' on your tablet in full-screen mode.

STEP 5: RUN THE DIAGNOSTIC TEST (DEPLOYMENT VERIFICATION)
---------------------------------------------------------
1. Open 'test-connection.html' or tap [ ðŸ§ª RUN WEBHOOK DIAGNOSTIC TEST ].
2. GREEN BANNER: Webhook is live. RED BANNER: Re-check quotation marks on line 8.
